//
//  Calculator.swift
//  iCalc
//
//  Created by Ospite on 02/05/17.
//  Copyright © 2017 Ospite. All rights reserved.
//

import Foundation

class Calculator{
    
    var numberDisplay:Double
    var numberOperation:Double
    
    
    enum Operation {
        case add
        case subtract
        case divide
        case multiply
        case noOperation
    }
    var currentOperation:Operation
    
    
    
    init() {
        numberDisplay=0
        numberOperation=0
        currentOperation = Operation.noOperation
    }
    
    func add(number:Double) -> Void {
        currentOperation = Operation.add
        numberOperation = number
    }
    func minus(number:Double) -> Void {
        currentOperation = Operation.subtract
        numberOperation = number
    }
    func moltiply(number:Double) -> Void {
        currentOperation = Operation.multiply
        numberOperation = number
    }
    func divide(number:Double) -> Void {
        currentOperation = Operation.divide
        numberOperation = number
    }
    func equal(number:Double) -> Void {
        numberOperation = number
    }
}
