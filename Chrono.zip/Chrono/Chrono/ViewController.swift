//
//  ViewController.swift
//  Chrono
//
//  Created by Ospite on 05/05/17.
//  Copyright © 2017 Sam. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var lblTime: UILabel!
    
    @IBOutlet weak var lblTimeLap: UILabel!
    
    @IBOutlet weak var btnPlay: UIButton!
    
    var started:Bool = false
    
    var timer = Timer()
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func btnPlay_TouchUpInside(_ sender: UIButton) {
        
        let btnPlay_ON:UIImage = UIImage(named: "PlayI")!
        let btnPause_ON:UIImage = UIImage(named: "Pause")!
        if started {
            btnPlay.setImage(btnPause_ON, for:UIControlState.normal)
            started = false
            timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(calcHour), userInfo: nil, repeats: false)
            lblTime.text =
        }
        else{
            btnPlay.setImage(btnPlay_ON, for: UIControlState.normal)
            started=true
        }
    }
    
    @IBAction func btnStop_TouchUpInside(_ sender: UIButton) {
    }
    
    @IBAction func btnClear_TouchUpInside(_ sender: UIButton) {
    }

    @IBAction func btnLap_TouchUpInside(_ sender: UIButton) {
    }
    
    func calcHour() -> Int {
        return 1
    }

}

