//
//  ViewController.swift
//  Primo
//
//  Created by Ospite on 28/04/17.
//  Copyright © 2017 Ospite. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var btnHello: UIButton!
    
    @IBOutlet weak var lblStatus: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func btnHello_TouchUpInside(_ sender: UIButton) {
        lblStatus.text = "Hello, World!"
        btnHello.setTitle("You press the Button!", for: UIControlState.normal)
    }

    @IBAction func btnHello_TouchDownRepeat(_ sender: UIButton) {
        
        lblStatus.text = "GoodBye, World!"
        btnHello.setTitle("You press repeat the Button!", for: UIControlState.normal)
    }
}

